import { createApp } from 'vue';
import App from './App.vue';
import { createRouter, createWebHashHistory } from 'vue-router';
import MainMenu from '@/components/MainMenu.vue';
import EbookPage from '@/components/EbookPage.vue';
import GamePage from '@/components/GamePage.vue';

const routes = [
  { path: '/', component: MainMenu },
  { path: '/ebook', component: EbookPage },
  { path: '/game', component: GamePage },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

const app = createApp(App);
app.use(router);
app.mount('#app');
