<template>
    <div>
      <div class="top-bar">
        <button @click="backToMainMenu">Back</button>
        <button @click="openChapterMenu">Chapters</button>
        <!-- Image item here! -->
      </div>
      <div id="minigame-sidebar">
        <!-- Sidebar with Minigame Toggles (you can add this feature) -->
        <div v-for="(minigame, index) in minigames" :key="index">
          {{ minigame.name }}: <span>{{ minigame.enabled ? '✓' : 'X' }}</span>
        </div>
      </div>
      <div id="points-display">
        <h2>Points: <span id="user-points">{{ userPoints }}</span></h2>
        <div>
          <button @click="adjustPoints('-')">-</button>
          <button @click="adjustPoints('+')">+</button>
        </div>
        <div id="context-window">
          <input type="number" v-model="pointInput" />
          <button @click="applyPoints">Apply</button>
        </div>
      </div>
      <div id="minigame-buttons">
        <!-- Minigame Buttons (you can add this feature) -->
        <button v-for="(minigame, index) in minigames" :key="index" @click="playMinigame(minigame)">
          Minigame {{ index + 1 }}
        </button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        userPoints: 0,
        pointInput: 0,
        minigames: [
          { name: 'Minigame 1', enabled: true, cooldown: 0 },
          // Add more minigames as needed
        ],
      };
    },
    methods: {
      backToMainMenu() {
        this.$router.push('/');
      },
      openChapterMenu() {
        // Implement opening chapter menu (you can add this feature)
        alert('Chapter menu not implemented yet!');
      },
      adjustPoints(operator) {
        this.userPoints = operator === '-' ? this.userPoints - 1 : this.userPoints + 1;
      },
      applyPoints() {
        this.userPoints += parseInt(this.pointInput);
        this.pointInput = 0;
      },
      playMinigame(minigame) {
        if (minigame.enabled && minigame.cooldown === 0) {
          // Minigame logic here
          alert(`Playing ${minigame.name}`);
          minigame.cooldown = 300; // Set cooldown to 5 minutes (300 seconds)
          setTimeout(() => {
            minigame.cooldown = 0;
          }, 300000);
        } else if (!minigame.enabled) {
          alert('Minigame is disabled');
        } else {
          alert('Minigame is on cooldown');
        }
      },
    },
  };
  </script>
  