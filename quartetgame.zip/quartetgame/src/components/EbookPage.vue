<template>
    <div>
      <div class="top-bar">
        <button @click="backToMainMenu">Back</button>
        <button @click="openChapterMenu">Chapters</button>
        <!-- Image item here! -->
      </div>
      <div id="ebook-content">
        <h2>{{ currentChapter.title }}</h2>
        <p>{{ currentChapter.content }}</p>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        currentChapter: {
          title: 'Chapter 1: Down the Rabbit Hole',
          content: 'Alice was beginning to get very tired of sitting by her sister on the bank...',
        },
      };
    },
    methods: {
      backToMainMenu() {
        this.$router.push('/');
      },
      openChapterMenu() {
        // Implement opening chapter menu (you can add this feature)
        alert('Chapter menu not implemented yet!');
      },
    },
  };
  </script>
  