<template>
    <div>
      <h1>Quartet in Wonderland</h1>

        <div class="row">
            <button class="learn-more" id="gamebutton" @click="loadGame">Play Game</button>
        </div>
            
        <div class="row">
            <button class="learn-more" id="readbutton" @click="loadEbook">Read</button>
        </div>

        <div class="row">
            <button class="learn-more" id="settingsbutton" @click="openSettings">Settings</button>
        </div>

      

    </div>
  </template>
  
  <script>
  export default {
    methods: {
      loadEbook() {
        this.$router.push('/ebook');
      },
      loadGame() {
        this.$router.push('/game');
      },
      openSettings() {
        // Implement opening settings (you can add this feature)
        alert('Settings not implemented yet!');
      },
    },
  };
  </script>
  


  <style scoped>
    #gamebutton {
  
    }
  
    #readbutton {
  
    }
  
    #settingsbutton {
  
    }
  
    @import url('https://fonts.googleapis.com/css?family=Rubik:700&display=swap');
  
    * {
      box-sizing: border-box;
    }
  
    *::before, *::after {
      box-sizing: border-box;
    }
  
    body {
      font-family: 'Rubik', sans-serif;
      font-size: 1rem;
      line-height: 1.5;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0;
      min-height: 100vh;
      background: rgb(13, 45, 97);
    }
  
    button {
      margin-top: 4%;
      position: relative;
      display: inline-block;
      cursor: pointer;
      outline: none;
      border: 0;
      vertical-align: middle;
      text-decoration: none;
      font-size: inherit;
      font-family: inherit;
    }
  
    button.learn-more {
      font-weight: 600;
      color: #382b22;
      text-transform: uppercase;
      padding: 1.25em 2em;
      background: #fff0f0;
      border: 2px solid #b18597;
      border-radius: 0.75em;
      transform-style: preserve-3d;
      transition: transform 150ms cubic-bezier(0, 0, 0.58, 1), background 150ms cubic-bezier(0, 0, 0.58, 1);
    }
  
    button.learn-more::before {
      position: absolute;
      content: '';
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: #f9c4d2;
      border-radius: inherit;
      box-shadow: 0 0 0 2px #b18597, 0 0.625em 0 0 #ffe3e2;
      transform: translate3d(0, 0.75em, -1em);
      transition: transform 150ms cubic-bezier(0, 0, 0.58, 1), box-shadow 150ms cubic-bezier(0, 0, 0.58, 1);
    }
  
    button.learn-more:hover {
      background: #ffe9e9;
      transform: translate(0, 0.25em);
    }
  
    button.learn-more:hover::before {
      box-shadow: 0 0 0 2px #b18597, 0 0.5em 0 0 #ffe3e2;
      transform: translate3d(0, 0.5em, -1em);
    }
  
    button.learn-more:active {
      background: #ffe9e9;
      transform: translate(0em, 0.75em);
    }
  
    button.learn-more:active::before {
      box-shadow: 0 0 0 2px #b18597, 0 0 #ffe3e2;
      transform: translate3d(0, 0, -1em);
    }
  </style>
 