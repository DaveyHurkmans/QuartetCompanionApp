<template>
  <div id="app">
    <!-- Navigation Bar -->
    <router-link to="/">Home</router-link>
    <router-link to="/ebook">Ebook</router-link>
    <router-link to="/game">Game</router-link>

    <!-- Router View to Display Components -->
    <router-view></router-view>
  </div>
</template>

<style>
html {
  background: #2c3e50;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #fff;
  margin-top: 60px; /* Adjust as needed */
}

router-link {
  margin-right: 10px;
  text-decoration: none;
  color: #72b6e3;
}

router-link:hover {
  text-decoration: underline;
  color: #fff;
}
</style>

